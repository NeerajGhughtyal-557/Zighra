package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.zighra.kineticlib.API.Kinetic;
import com.zighra.kineticlib.API.KineticFactory;

public class MainActivity extends AppCompatActivity {

    private Kinetic mKinetic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mKinetic = KineticFactory.getKinetic(this);

        String uName = "Neeraj";
        String uCode = "1111";



        mKinetic.setProfile(uName, uCode, new Kinetic.OnSetProfileSuccessListener() {
                    @Override
                    public void onSuccess(Kinetic.ProfileResponse profileResponse) {
                        Toast.makeText(MainActivity.this, " Success ", Toast.LENGTH_SHORT).show();
                    }},
                new Kinetic.OnSetProfileFailureListener() {
                    @Override
                    public void onFailure(Kinetic.ProfileResponse profileResponse) {
                        Toast.makeText(MainActivity.this, " Failure ", Toast.LENGTH_SHORT).show();
                    }
                });


        mKinetic.checkDevice(new Kinetic.OnCheckDeviceSuccessListener() {
            @Override
            public void onSuccess(Kinetic.CheckDeviceResponse checkDeviceResponse) {
                Toast.makeText(MainActivity.this, " Success ", Toast.LENGTH_SHORT).show();
            }
        }, new Kinetic.OnCheckDeviceFailureListener() {
            @Override
            public void onFailure(Kinetic.CheckDeviceResponse checkDeviceResponse) {
                Toast.makeText(MainActivity.this, " Failure ", Toast.LENGTH_SHORT).show();
            }
        });

    }
}